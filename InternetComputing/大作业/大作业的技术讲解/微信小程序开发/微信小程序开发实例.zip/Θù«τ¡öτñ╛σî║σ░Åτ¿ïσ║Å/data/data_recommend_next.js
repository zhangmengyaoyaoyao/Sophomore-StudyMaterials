module.exports = {

};

var next = {
  "id": 6,
  "data": [
    {
      "question_id": 1,
      "question_img": "../../images/icon1.jpeg",
      "question": "选择 Kindle 而不是纸质书的原因是什么？",
      "hot": "18"
    },
    {
      "question_id": 2,
      "question_img": "../../images/icon8.jpg",
      "question": "如何评价周杰伦的「中文歌才是最屌的」的言论？",
      "hot": "18"
    },
    {
      "question_id": 3,
      "question_img": "../../images/icon9.jpeg",
      "question": "气象铁塔的辐射大吗？",
      "hot": "18"
    },
    {
      "question_id": 4,
      "question_img": "../../images/icon1.jpeg",
      "question": "选择 Kindle 而不是纸质书的原因是什么？",
      "hot": "18"
    }
  ]
}
module.exports.next = next;