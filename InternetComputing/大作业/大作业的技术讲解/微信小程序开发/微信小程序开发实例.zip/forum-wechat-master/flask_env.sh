#!/usr/bin/env bash

export FLASK_APP=app
export FLASK_ENV=local-devel # development/product
