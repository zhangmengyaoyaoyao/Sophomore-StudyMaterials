package cpu.alu;

import util.DataType;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 */
public class ALU {
    public static void main(String[] args){
        DataType src = new DataType("00000000000000000000000000001000");
        DataType dest = new DataType("11110100000000000000000000000000");
        System.out.println(add(src,dest));
    }

    /**
     * 返回两个二进制整数的和
     * dest + src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public static DataType add(DataType src, DataType dest) {
        String srcStr = src.toString();
        String destStr = dest.toString();
        String c = "0";
        String ci = getCi(srcStr, destStr, c);
        
        String si = getSi(srcStr, destStr, ci);
        // System.out.println(ci);
        // System.out.println(si);
        return new DataType(si);

        //用全先行进位加法器的思想，做不下去，而且想不懂这在程序中是否能节省时间
        // String srcStr = src.toString();
        // String destStr = dest.toString();
        // String pi = "";
        // String gi = "";
        // for(int i = 0; i < 32; i++){
        //     pi += (srcStr.charAt(i)-'0') & (destStr.charAt(i)-'0');
        //     gi += (srcStr.charAt(i)-'0') | (destStr.charAt(i)-'0');
        // }
        // System.out.println(pi);
        // String ci = "";
        // for(int i = 0; i < 32; i++){
        //     ci += gi.charAt(i);
        //     for(int j = 0; j < i; j++){
        //         ci.charAt(i) |= 
        //     }

        // }


    }

    /**
     * 返回两个二进制整数的差
     * dest - src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public static DataType sub(DataType src, DataType dest) {
        // String negateSrc = "";
        // String srcStr = src.toString();
        // String destStr = dest.toString();
        // for(int i = 0; i < 32; i++){
        //     negateSrc += (srcStr.charAt(i)-'0') ^ 1;
        // }
        // String c = "1";
        // String ci = getCi(negateSrc, destStr, c);
        
        // String si = getSi(negateSrc, destStr, ci);
        // // System.out.println(ci);
        // // System.out.println(si);
        // return new DataType(si);

        String Src = src.toString();

        char[] c = new char[32];
        for (int i = 0; i < 32; i++) {
            c[i] = (char) ('1' + '0' - Src.charAt(i));
        }
        DataType New_Src = new DataType(String.valueOf(c));
        return add(New_Src, add(dest, new DataType("00000001")));
    }

    public static String getCi(String srcStr, String destStr,String c){
        String ci = c; //c0-c32
        for(int i = 31; i >= 0; i--){
            ci =(((srcStr.charAt(i)-'0') & (ci.charAt(0)-'0')) | 
            ((destStr.charAt(i)-'0') & (ci.charAt(0)-'0')) | ((srcStr.charAt(i)-'0') & (destStr.charAt(i)-'0')))+ ci;
        }
        return ci;
    }

    public static String getSi(String srcStr, String destStr, String ci){
        String si = "";
        for(int i = 31; i >= 0; i--){
            si = ((srcStr.charAt(i)-'0') ^ (destStr.charAt(i)-'0') ^ (ci.charAt(i+1)-'0')) + si;
        }
        return si;
    }
}
