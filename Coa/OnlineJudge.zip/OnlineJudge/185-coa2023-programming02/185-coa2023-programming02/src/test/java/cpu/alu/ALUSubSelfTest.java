package cpu.alu;

import org.junit.Test;
import util.DataType;

import static org.junit.Assert.assertEquals;

public class ALUSubSelfTest {

    private final ALU alu = new ALU();
    private DataType src;
    private DataType dest;
    private DataType result;

    @Test
    public void SubTest1() {
        src = new DataType("10000000000000000000000000000000");
        dest = new DataType("01111111111111111111111111111111");
        result = alu.sub(src, dest);
        assertEquals("11111111111111111111111111111111", result.toString());
    }

}
