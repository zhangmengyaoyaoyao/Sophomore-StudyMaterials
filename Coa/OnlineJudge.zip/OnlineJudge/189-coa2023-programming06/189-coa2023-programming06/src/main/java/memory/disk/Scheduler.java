package memory.disk;

import java.lang.reflect.Array;
import java.util.Arrays;

import javax.sound.midi.Track;

public class Scheduler {
    public static final int TRACK_NUM = 256;        // 磁道数

    /**
     * 先来先服务算法
     *
     * @param start   磁头初始位置
     * @param request 请求访问的磁道号
     * @return 平均寻道长度
     */
    public double FCFS(int start, int[] request) {
        int numOfRequest = request.length;
        double len_Average = 0;
        double len_Sum = 0;
        for(int r = 0; r < numOfRequest; r++){
            len_Sum += Math.abs(start - request[r]);
            start = request[r];
        }
        len_Average = len_Sum / numOfRequest;
        return len_Average;
        //TODO
    }

    /**
     * 最短寻道时间优先算法
     *
     * @param start   磁头初始位置
     * @param request 请求访问的磁道号
     * @return 平均寻道长度
     */
    public double SSTF(int start, int[] request) {
        int numOfRequest = request.length;
        double len_Average = 0;
        double len_Sum = 0;
        boolean[] isServiced = new boolean[numOfRequest];
        for(int i = 0; i < numOfRequest; i++){
            isServiced[i] = false;
        }

        int shortestReqIndex = -1;
        int shortestReqLen = -1;
        for(int r = 0; r < numOfRequest; r ++){
            for(int c = 0; c < numOfRequest; c++){
                if(shortestReqLen == -1 && !isServiced[c]){
                shortestReqLen = Math.abs(start - request[c]);
                shortestReqIndex = c; 
                break;                   
                }
            }
            for(int c = 0; c < numOfRequest; c++){
                if(!isServiced[c]){
                    int lenTemp = Math.abs(start - request[c]);
                    if(shortestReqLen > lenTemp){
                        shortestReqLen = lenTemp;
                        shortestReqIndex = c;
                    }
                }
            }
            isServiced[shortestReqIndex] = true;
            len_Sum += shortestReqLen;   
            start = request[shortestReqIndex];
            shortestReqIndex = -1;
            shortestReqLen = -1;
        }
        len_Average = len_Sum / numOfRequest;
        return len_Average;
        //TODO
    }

    /**
     * 扫描算法
     *
     * @param start     磁头初始位置
     * @param request   请求访问的磁道号
     * @param direction 磁头初始移动方向，true表示磁道号增大的方向，false表示磁道号减小的方向
     * @return 平均寻道长度
     */
    public double SCAN(int start, int[] request, boolean direction) {
        int numOfRequest = request.length;
        double len_Average = 0;
        double len_Sum = 0;
        Arrays.sort(request);
        int startIndex = numOfRequest;
        // *(0) 1 3 6 *(7) [9] 11 14 16 *(20)
        for(int c = 0; c < numOfRequest; c++){
            if(start <= request[c]){
                startIndex = c;
                break;
            }
        }
        if(direction){
            if(startIndex == numOfRequest){
                len_Sum = TRACK_NUM-1 - start + TRACK_NUM-1 - request[0];
            }else if(startIndex == 0){
                len_Sum = request[numOfRequest-1] - start;
            }else{
                len_Sum = TRACK_NUM-1 - start + TRACK_NUM-1 - request[0];
            }
        }else{
            if(startIndex == numOfRequest){
                len_Sum = start - request[0];
            }else{
                len_Sum = start + request[numOfRequest - 1];
            }
        }
        len_Average = len_Sum / numOfRequest;
        return len_Average;
        //TODO
    }

    /**
     * C-SCAN算法：默认磁头向磁道号增大方向移动
     *
     * @param start     磁头初始位置
     * @param request   请求访问的磁道号
     * @return 平均寻道长度
     */
    public double CSCAN(int start,int[] request){
        int numOfRequest = request.length;
        double len_Average = 0;
        double len_Sum = 0;
        Arrays.sort(request);
        int startIndex = numOfRequest;
        // *(0) 1 3 6 *(7) [9] 11 14 16 *(20)
        for(int c = 0; c < numOfRequest; c++){
            if(start <= request[c]){
                startIndex = c;
                break;
            }
        }
        if(startIndex == numOfRequest){
                len_Sum = TRACK_NUM-1 - start + TRACK_NUM-1 - request[0];
        }else if(startIndex == 0){
            len_Sum = request[numOfRequest-1] - start;
        }else{
            len_Sum = TRACK_NUM-1 - start + TRACK_NUM-1 + request[startIndex-1];
        }
    
        len_Average = len_Sum / numOfRequest;
        return len_Average;
        //TODO
    }

    /**
     * LOOK算法
     *
     * @param start     磁头初始位置
     * @param request   请求访问的磁道号
     * @param direction 磁头初始移动方向，true表示磁道号增大的方向，false表示磁道号减小的方向
     * @return 平均寻道长度
     */
    public double LOOK(int start,int[] request,boolean direction){
        int numOfRequest = request.length;
        double len_Average = 0;
        double len_Sum = 0;
        Arrays.sort(request);
        int startIndex = numOfRequest;
        // *(0) 1 3 6 *(7) [9] 11 14 16 *(20)
        for(int c = 0; c < numOfRequest; c++){
            if(start <= request[c]){
                startIndex = c;
                break;
            }
        }
        if(direction){
            if(startIndex == numOfRequest){
                len_Sum = TRACK_NUM-1 - start + TRACK_NUM-1 - request[0];
            }else if(startIndex == 0){
                len_Sum = request[numOfRequest-1] - start;
            }else{
                len_Sum = request[numOfRequest-1] - start + request[numOfRequest-1] - request[0];
            }
        }else{
            if(startIndex == numOfRequest){
                len_Sum = start - request[0];
            }else if(startIndex == 0){
                len_Sum = request[numOfRequest-1] - start;
            }else{
                len_Sum = start - request[0] + request[numOfRequest - 1] - request[0];
            }
        }
        len_Average = len_Sum / numOfRequest;
        return len_Average;
        //TODO
    }

    /**
     * C-LOOK算法：默认磁头向磁道号增大方向移动
     *
     * @param start     磁头初始位置
     * @param request   请求访问的磁道号
     * @return 平均寻道长度
     */
    public double CLOOK(int start,int[] request){
        int numOfRequest = request.length;
        double len_Average = 0;
        double len_Sum = 0;
        Arrays.sort(request);
        int startIndex = numOfRequest;
        // *(0) 1 3 6 *(7) [9] 11 14 16 *(20)
        for(int c = 0; c < numOfRequest; c++){
            if(start <= request[c]){
                startIndex = c;
                break;
            }
        }
        if(startIndex == numOfRequest){
            len_Sum = TRACK_NUM-1 - start + TRACK_NUM-1 - request[0];
        }else if(startIndex == 0){
            len_Sum = request[numOfRequest-1] - start;
        }else{
            len_Sum = request[numOfRequest-1] - start + request[numOfRequest-1] - request[0] + (request[startIndex-1]-request[0]);
        }
    
        len_Average = len_Sum / numOfRequest;
        return len_Average;
        //TODO
    }

}
