package memory.cache;

import memory.Memory;
import memory.cache.cacheReplacementStrategy.ReplacementStrategy;
import util.Transformer;
import java.util.Arrays;

/**
 * 高速缓存抽象类
 */
public class Cache {

    public static final boolean isAvailable = true; // 默认启用Cache

    public static final int CACHE_SIZE_B = 32 * 1024; // 32 KB 总大小

    public static final int LINE_SIZE_B = 64; // 64 B 行大小

    private final CacheLine[] cache = new CacheLine[CACHE_SIZE_B / LINE_SIZE_B];//表示Cache中的一行

    private int SETS;   // 组数

    private int setSize;    // 每组行数
    public static void main(String[] args){
        Memory memory = Memory.getMemory();
        // byte[] data = {0b00000001, 0b00000010, 0b000000011, 0b00000100};
        // String pAddr = "00000000000000000000000000000001";
        // memory.write(pAddr, data.length, data);
        byte[] data = {0b00000001, 0b00000010, 0b000000011, 0b00000100};
        String pAddr = "00000000000000001000000000000001";
        memory.write(pAddr, data.length, data);
    }

    // 单例模式
    private static final Cache cacheInstance = new Cache();

    private Cache() {
        for (int i = 0; i < cache.length; i++) {
            cache[i] = new CacheLine();
        }
    }

    public static Cache getCache() {
        return cacheInstance;
    }

    private ReplacementStrategy replacementStrategy;    // 替换策略

    public static boolean isWriteBack;   // 写策略

    /**
     * 读取[pAddr, pAddr + len)范围内的连续数据，可能包含**多个数据块**的内容
     *
     * @param pAddr 数据起始点(32位物理地址 = 26位块号 + 6位块内地址)
     * @param len   待读数据的字节数
     * @return 读取出的数据，以char数组的形式返回
     */
    public byte[] read(String pAddr, int len) {
        byte[] data = new byte[len];
        int addr = Integer.parseInt(Transformer.binaryToInt("0" + pAddr));
        int upperBound = addr + len;
        int index = 0;
        while (addr < upperBound) {
            int nextSegLen = LINE_SIZE_B - (addr % LINE_SIZE_B);//(64-地址号%64)*****|||||
            if (addr + nextSegLen >= upperBound) {// |||||||||||*****|||||
                nextSegLen = upperBound - addr;//  *****
            }
            int rowNO = fetch(Transformer.intToBinary(String.valueOf(addr)));
            byte[] cache_data = cache[rowNO].getData();
            int i = 0;
            while (i < nextSegLen) {
                data[index] = cache_data[addr % LINE_SIZE_B + i];
                index++;
                i++;
            }
            addr += nextSegLen;
        }
        return data;
    }

    /**
     * 向cache中写入[pAddr, pAddr + len)范围内的连续数据，可能包含多个数据块的内容
     *
     * @param pAddr 数据起始点(32位物理地址 = 26位块号 + 6位块内地址)
     * @param len   待写数据的字节数
     * @param data  待写数据
     */
    public void write(String pAddr, int len, byte[] data) {
        int addr = Integer.parseInt(Transformer.binaryToInt("0" + pAddr));
        int upperBound = addr + len;
        int index = 0;
        while (addr < upperBound) {
            int nextSegLen = LINE_SIZE_B - (addr % LINE_SIZE_B);
            if (addr + nextSegLen >= upperBound) {
                nextSegLen = upperBound - addr;
            }
            int rowNO = fetch(Transformer.intToBinary(String.valueOf(addr)));
            byte[] cache_data = cache[rowNO].getData();
            int i = 0;
            while (i < nextSegLen) {
                cache_data[addr % LINE_SIZE_B + i] = data[index];
                index++;
                i++;
            }

            //TODO
            if(isWriteBack){ //写直达策略就是在write函数完成写Cache后直接修改主存
                cache[rowNO].dirty = true;
            }else{  //写直达策略就是在write函数完成写Cache后直接修改主存
                Memory memory = Memory.getMemory();
                String memorypAddr = calc_pAddrFromRowNO(rowNO);
                memory.write(memorypAddr, LINE_SIZE_B, cache_data);
                //memory.write(memorypAddr, nextSegLen, cache_data);
                /*
                 * 一开始这样写，需要写入的数据长度错了。因为这里的cache_data是由cache[rowNO].getData()得到的，
                 * 是一整行的数据，不是修改过的数据。
                 * 应该有数据长度更精确的写法？把修改过的数据（data数组的某几个）写入，此时数据长度应该就是nextSegLen了。
                 */
            }
            
            addr += nextSegLen;
        }
    }


    /**
     * 计算出数据所在的块号，然后调用map方法查询数据块在Cache中的行号。
     * 如果目标数据块不在Cache内，则需要将数据从内存读到Cache（需要阅读Memory类源码），
     * 并返回被更新的Cache行的行号。
     * 
     * 查询{@link Cache#cache}表以确认包含pAddr的数据块是否在cache内
     * 如果目标数据块不在Cache内，则将其从内存加载到Cache
     *
     * @param pAddr 数据起始点(32位物理地址 = 26位块号 + 6位块内地址)
     * @return 数据块在Cache中的对应行号
     */
    private int fetch(String pAddr) {
        //计算出数据所在的块号
        int blockNO = getBlockNO(pAddr);
        int mp_rowNO = map(blockNO);
        //cache中没有找到我们需要的块
        if(mp_rowNO == -1){
            byte[] input = Memory.getMemory().read(Transformer.intToBinary(String.valueOf(LINE_SIZE_B*blockNO)),LINE_SIZE_B);
            char[] tag = calc_tag(blockNO);
            if(replacementStrategy == null){ //直接映射没有替换策略
                  //直接映射里，区分可能在同一行的不同块
                mp_rowNO = blockNO % SETS; //需要更新的行号
                update(mp_rowNO, tag, input);
            }else{
                int setID = blockNO % SETS; //计算组号的方法：块号对组数取余
                int fromLine = setID * setSize;
                int toLine = (setID + 1) * setSize;
                mp_rowNO = this.replacementStrategy.replace(fromLine, toLine, tag, input);
            }
        }
        //TODO
        return mp_rowNO;
    }


    /**
     * 根据目标数据内存地址前26位的int表示，进行映射
     *
     * @param blockNO 数据在内存中的块号
     * @return 返回cache中所对应的行，-1表示未命中
     */
    private int map(int blockNO) {
        int setID = blockNO % SETS; //计算组号的方法：块号对组数取余
        char[] tag = calc_tag(blockNO);
        int fromLine = setID * setSize;
        int toLine = (setID + 1) * setSize;
        for(int rowNO = fromLine; rowNO < toLine; rowNO++){
            /**
             * @Mlg
             * 少了对无效数据的过滤
             * */
            if(cacheInstance.isValid(rowNO) && Arrays.equals(calc_tag(blockNO), cache[rowNO].getTag())){
                if (replacementStrategy != null) this.replacementStrategy.hit(rowNO);
                return rowNO;
            }
        }
        return -1;
        //TODO
    }

    
    /**
     * 根据快好得出26位tag
     * @param blockNO
     * @return
     */
    private char[] calc_tag(int blockNO){
        int tag = blockNO / SETS;
        int tagLen = 26 - (int)(Math.log(SETS) / Math.log(2));
        String tagStr = Transformer.intToBinary(""+tag).substring(32-tagLen, 32);
        int diff = 26 - tagLen;
        for(int i = 0; i < diff; i++){
            tagStr = "0" + tagStr;
        }
        return tagStr.toCharArray();
        // //MEM_SIZE_B是私有变量，怎么解决？？
        // int tagLen = 26 - (int)(Math.log(SETS) / Math.log(2));
        // String tagStr = Transformer.intToBinary(String.valueOf(blockNO)).substring(6,6+tagLen);
        // return tagStr.toCharArray();       

    }

    public String calc_pAddrFromRowNO(int rowNO){
        int tagLen = 26-(int)(Math.log(SETS)/Math.log(2));
        String tagStr = String.valueOf(cache[rowNO].getTag()).substring(26-tagLen);
        int setNO = rowNO / setSize;
        String setNOStr = Transformer.intToBinary(setNO+"").substring(32-(26-tagLen));
        int offset = rowNO % setSize;
        String offsetStr = Transformer.intToBinary(offset+"").substring(32-6);
        return tagStr+setNOStr+offsetStr;

        // int tagLen = 26 - (int)(Math.log(SETS) / Math.log(2));
        // int setID = rowNO / setSize;
        // String setIDStr = Transformer.intToBinary(String.valueOf(setID)).substring(32-(26-tagLen));
        // int blockOffset = rowNO % setSize;
        // String blockOffsetStr = Transformer.intToBinary(String.valueOf(blockOffset)).substring(26);
        // char[] tag = cache[rowNO].getTag();
        // String tagStr = "";
        // for(int i = 26-tagLen; i < 26; i++){
        //     tagStr += tag[i];
        // }
        // String pAddr = tagStr + setIDStr + blockOffsetStr;
        // return pAddr;

        // int tag = Integer.parseInt(Transformer.binaryToInt(cache[rowNO].getTag().toString()));
        // int blockNO = tag * SETS + rowNO/setSize;
        // String blockNOStr = Transformer.intToBinary(String.valueOf(blockNO)).substring(6);
        // int blockOffset = rowNO % setSize;
        // String blockOffsetStr = Transformer.intToBinary(String.valueOf(blockOffset)).substring(26);
        // return blockOffsetStr+blockOffsetStr;
    }
    /**
     * 更新cache
     *
     * @param rowNO 需要更新的cache行号
     * @param tag   待更新数据的Tag
     * @param input 待更新的数据
     */
    public void update(int rowNO, char[] tag, byte[] input) {
        cache[rowNO].validBit = true;
        cache[rowNO].dirty = false;
        cache[rowNO].visited = 0;
        cache[rowNO].timeStamp = 0L;
        cache[rowNO].tag = tag;
        cache[rowNO].data = input;
        //TODO
    }


    /**
     * 从32位物理地址(26位块号 + 6位块内地址)获取目标数据在内存中对应的块号
     *
     * @param pAddr 32位物理地址
     * @return 数据在内存中的块号
     */
    private int getBlockNO(String pAddr) {
        return Integer.parseInt(Transformer.binaryToInt("0" + pAddr.substring(0, 26)));
    }


    /**
     * 该方法会被用于测试，请勿修改
     * 使用策略模式，设置cache的替换策略
     *
     * @param replacementStrategy 替换策略
     */
    public void setReplacementStrategy(ReplacementStrategy replacementStrategy) {
        this.replacementStrategy = replacementStrategy;
    }

    /**
     * 该方法会被用于测试，请勿修改
     *
     * @param SETS 组数
     */
    public void setSETS(int SETS) {
        this.SETS = SETS;
    }

    /**
     * 该方法会被用于测试，请勿修改
     *
     * @param setSize 每组行数
     */
    public void setSetSize(int setSize) {
        this.setSize = setSize;
    }

    /**
     * 告知Cache某个连续地址范围内的数据发生了修改，缓存失效
     * 该方法仅在memory类中使用，请勿修改
     *
     * @param pAddr 发生变化的数据段的起始地址
     * @param len   数据段长度
     */
    public void invalid(String pAddr, int len) {
        int from = getBlockNO(pAddr);
        int to = getBlockNO(Transformer.intToBinary(String.valueOf(Integer.parseInt(Transformer.binaryToInt("0" + pAddr)) + len - 1)));

        for (int blockNO = from; blockNO <= to; blockNO++) {
            int rowNO = map(blockNO);
            if (rowNO != -1) {
                cache[rowNO].validBit = false;
            }
        }
    }

    /**
     * 清除Cache全部缓存
     * 该方法会被用于测试，请勿修改
     */
    public void clear() {
        for (CacheLine line : cache) {
            if (line != null) {
                line.validBit = false;
                line.dirty = false;
                line.timeStamp = 0L;
                line.visited = 0;
            }
        }
    }

    /**
     * 输入行号和对应的预期值，判断Cache当前状态是否符合预期
     * 这个方法仅用于测试，请勿修改
     *
     * @param lineNOs     行号
     * @param validations 有效值
     * @param tags        tag
     * @return 判断结果
     */
    public boolean checkStatus(int[] lineNOs, boolean[] validations, char[][] tags) {
        if (lineNOs.length != validations.length || validations.length != tags.length) {
            return false;
        }
        for (int i = 0; i < lineNOs.length; i++) {
            CacheLine line = cache[lineNOs[i]];
            if (line.validBit != validations[i]) {
                return false;
            }
            if (!Arrays.equals(line.getTag(), tags[i])) {
                return false;
            }
        }
        return true;
    }

    // 获取有效位
    public boolean isValid(int rowNO){
        return cache[rowNO].validBit;
    }

    // 获取脏位
    public boolean isDirty(int rowNO){
        return cache[rowNO].dirty;
    }

    // LFU算法增加访问次数
    public void addVisited(int rowNO){
        cache[rowNO].visited++;
    }

    // 获取访问次数
    public int getVisited(int rowNO){
        return cache[rowNO].visited;
    }

    // 用于LRU算法，重置时间戳
    public void setTimeStamp(int rowNO){
        cache[rowNO].timeStamp++;
    }
    public void setTimeStamp(int rowNO, Long timeNow){
        cache[rowNO].timeStamp = timeNow;
    }

    //用于FIFO算法，重置时间戳
    public void setTimeStampFIFO(int rowNo){
        cache[rowNo].timeStamp = 1L;
        if((rowNo+1)%setSize == 0){
            cache[rowNo+1-setSize].timeStamp = 0L;
        }else{
            cache[rowNo+1].timeStamp = 0L;
        }
    }

    // 获取时间戳
    public long getTimeStamp(int rowNO){
        return cache[rowNO].timeStamp;
    }

    // 获取该行数据
    public byte[] getData(int rowNO){
        return cache[rowNO].data;
    }

    /**
     * Cache行，每行长度为(1+22+{@link Cache#LINE_SIZE_B})
     */
    private static class CacheLine {

        // 有效位，标记该条数据是否有效
        boolean validBit = false;

        // 脏位，标记该条数据是否被修改
        boolean dirty = false;

        // 用于LFU算法，记录该条cache使用次数
        int visited = 0;

        // 用于LRU和FIFO算法，记录该条数据时间戳
        Long timeStamp = 0L;

        // 标记，占位长度为26位，有效长度取决于映射策略：
        // 直接映射: 17 位
        // 全关联映射: 26 位
        // (2^n)-路组关联映射: 26-(9-n) 位
        // 注意，tag在物理地址中用高位表示，如：直接映射(32位)=tag(17位)+行号(9位)+块内地址(6位)，
        // 那么对于值为0b1111的tag应该表示为00000000000000000000001111，其中低12位为有效长度
        char[] tag = new char[26];

        // 数据
        byte[] data = new byte[LINE_SIZE_B];

        byte[] getData() {
            return this.data;
        }

        char[] getTag() {
            return this.tag;
        }

    }
}
