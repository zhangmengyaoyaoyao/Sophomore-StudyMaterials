package memory.cache.cacheReplacementStrategy;

import memory.Memory;
import memory.cache.Cache;

/**
 * TODO 最近最少用算法
 */
public class LRUReplacement implements ReplacementStrategy {
    Cache cache = Cache.getCache();
    static Long timeNow = 0L;

    @Override
    public void hit(int rowNO) {
        timeNow++;
        cache.setTimeStamp(rowNO,timeNow);
        //TODO
    }

    @Override
    public int replace(int start, int end, char[] addrTag, byte[] input) {
        //先找无效行,若存在则第一个无效行进行替换
        for(int rowNONow = start; rowNONow < end; rowNONow++){
            if(!cache.isValid(rowNONow)){
                cache.update(rowNONow, addrTag, input);
                cache.setTimeStamp(rowNONow,timeNow);
                return rowNONow;
            }
        }

        Long earliestVisitTime = cache.getTimeStamp(start);
        int earliestVisitRowNO = start;
        for(int rowNONow = start; rowNONow < end; rowNONow++){
            if(cache.getTimeStamp(rowNONow) < earliestVisitTime){
                earliestVisitTime = cache.getTimeStamp(rowNONow);
                earliestVisitRowNO = rowNONow;
            }
        }
        //写回法在replace函数将要替换掉该行的时候将该行写回内存。
        if(Cache.isWriteBack && cache.isDirty(earliestVisitRowNO)){
            Memory memory = Memory.getMemory();
            String memorypAddr = cache.calc_pAddrFromRowNO(earliestVisitRowNO);
            memory.write(memorypAddr, Cache.LINE_SIZE_B, cache.getData(earliestVisitRowNO));
        }
        cache.update(earliestVisitRowNO, addrTag, input);
        cache.setTimeStamp(earliestVisitRowNO,timeNow);
        return earliestVisitRowNO;

        //TODO
    }

}





























