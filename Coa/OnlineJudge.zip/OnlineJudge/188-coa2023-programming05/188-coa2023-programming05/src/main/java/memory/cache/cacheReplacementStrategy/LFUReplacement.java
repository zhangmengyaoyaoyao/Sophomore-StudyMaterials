package memory.cache.cacheReplacementStrategy;

import memory.Memory;
import memory.cache.Cache;

/**
 * TODO 最近不经常使用算法
 */
public class LFUReplacement implements ReplacementStrategy {
    Cache cache = Cache.getCache();
    @Override
    public void hit(int rowNO) {
        cache.addVisited(rowNO);
        //TODO
    }

    @Override
    public int replace(int start, int end, char[] addrTag, byte[] input) {
        //先找无效行,若存在则第一个无效行进行替换
        for(int rowNONow = start; rowNONow < end; rowNONow++){
            if(!cache.isValid(rowNONow)){
                cache.update(rowNONow, addrTag, input);
                return rowNONow;
            }
        }
        
        int leastVisitTimes = cache.getVisited(start);
        int leastVisitRowNO = start;
        for(int rowNONow = start; rowNONow < end; rowNONow++){
            if(cache.getVisited(rowNONow) < leastVisitTimes){
                leastVisitTimes = cache.getVisited(rowNONow);
                leastVisitRowNO = rowNONow;
            }
        }
        //写回法在replace函数将要替换掉该行的时候将该行写回内存。
        if(Cache.isWriteBack && cache.isDirty(leastVisitRowNO)){
            Memory memory = Memory.getMemory();
            String memorypAddr = cache.calc_pAddrFromRowNO(leastVisitRowNO);
            memory.write(memorypAddr, Cache.LINE_SIZE_B, cache.getData(leastVisitRowNO));
        }
        cache.update(leastVisitRowNO, addrTag, input);
        return leastVisitRowNO;

        //TODO
    }

}
