package memory.cache.cacheReplacementStrategy;

import java.io.CharArrayReader;

import memory.Memory;
import memory.cache.Cache;

/**
 * TODO 先进先出算法
 */
public class FIFOReplacement implements ReplacementStrategy {

    Cache cache = Cache.getCache();
    @Override
    /*
     * 结合具体的替换策略，进行命中后进行相关操作
     * 留给聪明的你自己思考啦
     */
    public void hit(int rowNO) {
        //在FIFO替换算法里，替换策略与访问无关，仅与读入顺序有关
        //Cache.getCache().setTimeStampFIFO(rowNO);
        //TODO
    }

    @Override
    /*
     * 在给定范围内，根据具体的策略，寻找出需要被替换的那一行并进行替换并返回行号
     */
    public int replace(int start, int end, char[] addrTag, byte[] input) {
        //先找无效行,若存在则第一个无效行进行替换
        for(int rowNONow = start; rowNONow < end; rowNONow++){
            if(!cache.isValid(rowNONow)){
                cache.update(rowNONow, addrTag, input);
                cache.setTimeStampFIFO(rowNONow);
                return rowNONow;
            }
        }
        
        for(int rowNONow = start; rowNONow < end; rowNONow++){
            if(cache.getTimeStamp(rowNONow) == 0L){
                //写回法在replace函数将要替换掉该行的时候将该行写回内存。
                if(Cache.isWriteBack && cache.isDirty(rowNONow)){
                    Memory memory = Memory.getMemory();
                    String memorypAddr = cache.calc_pAddrFromRowNO(rowNONow);
                    memory.write(memorypAddr, Cache.LINE_SIZE_B, cache.getData(rowNONow));
                }
                cache.update(rowNONow, addrTag, input);
                cache.setTimeStampFIFO(rowNONow);
                return rowNONow;

            }
        }
        
        
        //TODO
        return -1;
    }

}
