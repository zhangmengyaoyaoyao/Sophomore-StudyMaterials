package cpu.alu;

import javax.xml.crypto.Data;

import util.DataType;
import util.Transformer;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 */
public class ALU {
    public static void main(String[] args){
        // DataType src = new DataType(Transformer.intToBinary("2"));
        // DataType dest = new DataType(Transformer.intToBinary("-8"));
        // DataType result = div(src,dest);
        // System.out.println(result.toString());
        // DataType src = new DataType("01000000000000000000000000010000");
        // DataType dest = new DataType("01000000000000000000000000010000");
        // System.out.println(mul(src,dest));
        String a = "00";
        String b = "01";
        System.out.println(a.charAt(0) == b.charAt(0));
    }
    private static DataType SHL(DataType src, int p) { //左移p位
        String s = src.toString();
        StringBuilder res = new StringBuilder();
        for (int i = p; i < 32; i++) {
            res.append(s.charAt(i));
        }
        for (int i = 0; i < p; i++) {
            res.append('0');
        }
        return new DataType(res.toString());
    }

    /**
     * 返回两个二进制整数的乘积(结果低位截取后32位)
     * dest * src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    /*
    *  1.在ALU类中实现实现整数的二进制乘法(要求使用布斯乘法实现)。
        输入和输出均为32位二进制补码，计算结果直接截取低32位作为最终输出
    * */
    public static DataType mul(DataType src, DataType dest) {
        //10 -
        //01 +
        String Dest = dest.toString();
        Dest = Dest + "0";
        DataType res = new DataType("00000000");
        for (int i = 31; i >= 0; i--) {
            if (Dest.charAt(i) == '0' && Dest.charAt(i + 1) == '1') {
                res = add(res, SHL(src, 31 - i));
            } else if (Dest.charAt(i) == '1' && Dest.charAt(i + 1) == '0') {
                res = sub(SHL(src, 31 - i), res);
            }
        }

        return res;
    }

    // 定义 SHL 方法，用于实现左移 p 位操作
// src 表示要进行左移的数据，p 表示要左移的位数
private static String SHL(String src, int p) {
    // 定义 StringBuilder 对象 res，用于保存左移后的结果
    StringBuilder res = new StringBuilder();
    // 将 src 中从 p 位开始的字符依次添加到 res 中
    for (int i = p; i < 32; i++) {
        res.append(src.charAt(i));
    }
    // 在 res 的末尾添加 p 个 0
    for (int i = 0; i < p; i++) {
        res.append('0');
    }
    // 返回 res 的字符串形式
    return res.toString();
}

// 定义 mul 方法，用于实现两个数据的乘法操作
// src 和 dest 分别表示要进行乘法运算的两个数据
public static String multotal(DataType src, DataType dest) {
    // 将 src 和 dest 转换为字符串
    String Src = src.toString();
    String Dest = dest.toString();
    Dest = Dest + "0";
    // 定义 long 类型的变量 res，用于保存乘法的结果，初始化为 0
    long res = 0;
    // 从右往左遍历 Dest 的每一位
    for (int i = 31; i >= 0; i--) {
        // 如果当前位为 01，则将 res 加上 src 左移 31-i 位的结果
        if (Dest.charAt(i) == '0' && Dest.charAt(i + 1) == '1') {
            res += Long.valueOf(SHL(Src, 31 - i), 2) << 1;
        }
        // 如果当前位为 10，则将 res 减去 src 左移 31-i 位的结果
        else if (Dest.charAt(i) == '1' && Dest.charAt(i + 1) == '0') {
            res -= Long.valueOf(SHL(Src, 31 - i), 2) << 1;

        }
    }
    // 将 res 转换为 64 位二进制字符串并返回
    return String.format("%64s", Long.toBinaryString(res)).replace(' ', '0');
}

    // /**
    //  * 返回两个二进制整数的乘积(结果低位截取后32位)
    //  * dest * src
    //  *
    //  * @param src  32-bits 乘数
    //  * @param dest 32-bits 被乘数
    //  * @return 32-bits
    //  */
    // public static DataType mul(DataType src, DataType dest) {
    //     //初始化寄存器
    //     DataType result = new DataType("00000000000000000000000000000000");
    //     String srcRegister = src.toString()+"0";
    //     //计算Y0-Y1...
    //     int[] y = new int[32];
    //     for(int i = 0; i < 32; i++){
    //         y[i] = srcRegister.charAt(32-i) - srcRegister.charAt(31-i);
    //     }
    //     //jisuan
    //     for(int i = 0; i < 32; i++){
    //         if(y[i] == 1){
    //             result = add(dest , result);
    //         }else if(y[i] == -1){
    //             result = sub(dest, result);
    //         }
    //         //右移
    //         System.out.printf("y[%d]-y[%d] = %d\n",i,i-1,y[i]);
    //         srcRegister = result.toString().charAt(31)+srcRegister.substring(0,32);
    //         result = new DataType(result.toString().charAt(0)+result.toString().substring(0, 31));
    //         System.out.println(result.toString()+srcRegister);
    //     }
    //     result = new DataType(srcRegister.substring(0, 32));

    //     return result;
    // }

    static DataType remainderReg = new DataType("00000000000000000000000000000000");
    
    /**
     * 返回两个二进制整数的除法结果
     * dest ÷ src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     * 不回复余数除法
     */
    public static DataType div1(DataType src, DataType dest) {
        if( src.toString() .equals("00000000000000000000000000000000")){
            int a = 3;
            int b = 0;
            System.out.println(a/b);
            return null;
        }
        //初始化
        String quotientStr = dest.toString();
        String reminderStr = "";
        String tempStr;
        char symbolSrc = src.toString().charAt(0);
        //1
        char symbolDest = dest.toString().charAt(0);
        for(int i = 0; i < 32; i++){
            reminderStr += symbolDest;
        }
        //2
        // if(symbolDest == '0'){
        //     reminderStr = "00000000000000000000000000000000";
        // }else{
        //     reminderStr = "11111111111111111111111111111111";
        // }
        //3
        // if(dest.toString().charAt(0) == '0'){
        //     reminderStr = "00000000000000000000000000000000";
        // }else{
        //     reminderStr = "11111111111111111111111111111111";
        // }
        for(int i = 0; i < 32; i++){
            //左移R和Q
            reminderStr = reminderStr.substring(1, 32) + quotientStr.charAt(0);
            quotientStr = quotientStr.substring(1);
            if(reminderStr.charAt(0) == symbolSrc){
                tempStr = sub(src, new DataType(reminderStr)).toString();
            }else{
                tempStr = add(src, new DataType(reminderStr)).toString();
            }
            if((reminderStr.charAt(0) == tempStr.charAt(0) || !tempStr.contains("1") & !quotientStr.substring(0, 31-i).contains("1"))){
                quotientStr += "1";
                reminderStr = tempStr;
            }else{
                quotientStr += "0";
            }

        }
        DataType QReg;;
        if(dest.toString().charAt(0) == symbolSrc){
            QReg = new DataType(quotientStr);
        }else{
            QReg = sub(new DataType(quotientStr), new DataType("00000000000000000000000000000000"));
        }
        remainderReg = new DataType(reminderStr);
        return QReg;
        //return null;
    }

    static String zeroIn32 = "00000000000000000000000000000000";
    //public static DataType div_tryBeforeExam(DataType src, DataType dest) {
    public static DataType div(DataType src, DataType dest) {
        if(src.toString().equals(zeroIn32)){
            throw new ArithmeticException();
        }
        String Y = src.toString();
        String Q = dest.toString();
        String R = Q.substring(0, 1).equals("0")? "00000000000000000000000000000000" : "11111111111111111111111111111111";
        String temp = "";

        for(int i = 0; i < 32; i++){
            //1.R、Q左移一位
            R = R.substring(1).concat(Q.substring(0, 1));
            Q = Q.substring(1);
            //2.R-+Y
            if(R.charAt(0) == Y.charAt(0)){
                temp = sub(new DataType(Y), new DataType(R)).toString();
            }else{
                temp = add(new DataType(Y), new DataType(R)).toString();
            }
            //3.恢复？补0、1？
            //注意这里是temp.equals(zeroIn32)，不是R，用减后的判断
            if(temp.charAt(0) == R.charAt(0) || (temp.equals(zeroIn32) && !Q.substring(0, 31-i).contains("1"))){
                //够减：R不用恢复，补0
                R = temp;
                Q = Q.concat("1");
            }else{
                Q = Q.concat("0");
            }
            // if (R.charAt(0) ==temp.charAt(0) || !(R + Q.substring(0, 31 - i)).contains("1")) {
            //     Q = Q + "1";
            // } else {
            //     Q = Q + "0";
            //     R = rem_R;
            // }
        }
        //4.Q是否去补
        if(dest.toString().charAt(0) != src.toString().charAt(0)){
            Q = sub(new DataType(Q), new DataType(zeroIn32)).toString();
        }
        remainderReg = new DataType(R);
        return new DataType(Q);
    }


    /**
     * 返回两个二进制整数的和
     * dest + src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public static DataType add(DataType src, DataType dest) {
        // //这种getci的方法其实很慢，一次循环32次运算，一共就1024次了
        // String srcStr = src.toString();
        // String destStr = dest.toString();
        // String c = "0";
        // String ci = getCi(srcStr, destStr, c);
        
        // String si = getSi(srcStr, destStr, ci);
        // return new DataType(si);
        //这是mlg给出的一种比较快的算法

        
        String Src = src.toString(), Dest = dest.toString();
        StringBuilder res = new StringBuilder();
        int c = 0;
        for (int i = 31; i >= 0; i--) {
            boolean x = (Src.charAt(i) == '1');
            boolean y = (Dest.charAt(i) == '1');
            char z = '0';
            //模拟结果位和进位的真值表
            if (c == 0) {
                z = (x ^ y) ? '1' : '0';
                c = (x & y) ? 1 : 0;
            } else {
                z = (x ^ y ^ true) ? '1' : '0';
                c = (x | y) ? 1 : 0;
            }
            res.append(z);
        }
//
        return new DataType(res.reverse().toString());
    }

    /**
     * 返回两个二进制整数的差
     * dest - src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public static DataType sub(DataType src, DataType dest) {
        String negateSrc = "";
        String srcStr = src.toString();
        String destStr = dest.toString();
        for(int i = 0; i < 32; i++){
            negateSrc += (srcStr.charAt(i)-'0') ^ 1;
        }
        String c = "1";
        String ci = getCi(negateSrc, destStr, c);
        
        String si = getSi(negateSrc, destStr, ci);
        // System.out.println(ci);
        // System.out.println(si);
        return new DataType(si);
    }

    public static String getCi(String srcStr, String destStr,String c){
        String ci = c; //c0-c32
        for(int i = 31; i >= 0; i--){
            ci =(((srcStr.charAt(i)-'0') & (ci.charAt(0)-'0')) | 
            ((destStr.charAt(i)-'0') & (ci.charAt(0)-'0')) | ((srcStr.charAt(i)-'0') & (destStr.charAt(i)-'0')))+ ci;
        }
        return ci;
    }

    public static String getSi(String srcStr, String destStr, String ci){
        String si = "";
        for(int i = 31; i >= 0; i--){
            si = ((srcStr.charAt(i)-'0') ^ (destStr.charAt(i)-'0') ^ (ci.charAt(i+1)-'0')) + si;
        }
        return si;
    }

}
