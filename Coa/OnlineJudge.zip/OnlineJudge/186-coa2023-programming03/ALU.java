package cpu.alu;

import javax.xml.crypto.Data;

import util.DataType;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 */
public class ALU {
    /**
     * 返回两个二进制整数的和
     * dest + src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    private DataType add(DataType src, DataType dest) {
        // TODO
        String Src = src.toString(), Dest = dest.toString();
        StringBuilder res = new StringBuilder();
        int c = 0;
        for (int i = 31; i >= 0; i--) {
            boolean x = (Src.charAt(i) == '1');
            boolean y = (Dest.charAt(i) == '1');
            char z = '0';
            //模拟结果位和进位的真值表
            if (c == 0) {
                z = (x ^ y) ? '1' : '0';
                c = (x & y) ? 1 : 0;
            } else {
                z = (x ^ y ^ true) ? '1' : '0';
                c = (x | y) ? 1 : 0;
            }
            res.append(z);
        }
//
        return new DataType(res.reverse().toString());
    }

    /**
     * 返回两个二进制整数的差
     * dest - src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    private DataType sub(DataType src, DataType dest) {

        String Src = src.toString();

        char[] c = new char[32];
        for (int i = 0; i < 32; i++) {
            c[i] = (char) ('1' + '0' - Src.charAt(i));
        }
        DataType New_Src = new DataType(String.valueOf(c));
        return add(New_Src, add(dest, new DataType("00000001")));
    }

    private DataType SHL(DataType src, int p) { //左移p位
        String s = src.toString();
        StringBuilder res = new StringBuilder();
        for (int i = p; i < 32; i++) {
            res.append(s.charAt(i));
        }
        for (int i = 0; i < p; i++) {
            res.append('0');
        }
        return new DataType(res.toString());
    }

    /**
     * 返回两个二进制整数的乘积(结果低位截取后32位)
     * dest * src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    /*
    *  1.在ALU类中实现实现整数的二进制乘法(要求使用布斯乘法实现)。
        输入和输出均为32位二进制补码，计算结果直接截取低32位作为最终输出
    * */
    public DataType mul(DataType src, DataType dest) {
        //TODO
        //10 -
        //01 +
        String Dest = dest.toString();
        Dest = Dest + "0";
        DataType res = new DataType("00000000");
        for (int i = 31; i >= 0; i--) {
            if (Dest.charAt(i) == '0' && Dest.charAt(i + 1) == '1') {
                res = add(res, SHL(src, 31 - i));
            } else if (Dest.charAt(i) == '1' && Dest.charAt(i + 1) == '0') {
                res = sub(SHL(src, 31 - i), res);
            }
        }

        return res;
    }

    DataType remainderReg = new DataType("00000000000000000000000000000000");

    private DataType trans(char[] x) {
        return new DataType(String.valueOf(x));
    }

    /**
     * 返回两个二进制整数的除法结果
     * dest ÷ src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    /*
    *   2.实现整数的二进制除法 (dest ÷ src)，使用恢复余数除法和不恢复余数除法均可。
    *   输入为32位二进制补码，输出为32位商，并且将32位余数正确储存在余数寄存器remainderReg中。
        注意：除数为0，且被除数不为0时要求能够正确抛出ArithmeticException异常。
    * */
    public DataType div(DataType src, DataType dest) {
        DataType zero = new DataType("00000000");
        if (src.toString().equals(zero.toString())) {
            throw new ArithmeticException();
        }
        String Q = dest.toString(), R = "";
        String Src = src.toString();
        for (int i = 0; i < 32; i++) R += Q.charAt(0);
        String rem_R;
        for (int i = 0; i < 32; i++) {
            R = R.substring(1, 32) + Q.charAt(0);
            Q = Q.substring(1);
            rem_R = R;
            if (R.charAt(0) == Src.charAt(0)) R = sub(new DataType(Src), new DataType(R)).toString();
            else R = add(new DataType(Src), new DataType(R)).toString();
            if (R.charAt(0) ==rem_R.charAt(0) || !(R + Q.substring(0, 31 - i)).contains("1")) {
                Q = Q + "1";
            } else {
                Q = Q + "0";
                R = rem_R;
            }
        }
        if (Src.charAt(0) != dest.toString().charAt(0)) {
            Q = sub(new DataType(Q), zero).toString();
        }
        remainderReg = new DataType(R);
        return new DataType(Q);
    }

    public static void main(String[] args) {
        ALU alu = new ALU();
        DataType src = new DataType("00000000100000000000000000000000");
        DataType dest = new DataType("00000000100000000000000000000000");
        System.out.println(alu.mul(src, dest));
    }
}
