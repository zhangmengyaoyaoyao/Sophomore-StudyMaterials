package cpu.alu;

import javax.xml.crypto.Data;

import util.DataType;

public class ALU {
        /**
     * 返回两个二进制整数的和
     * dest + src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public static DataType add(DataType src, DataType dest) {
        String Src = src.toString(), Dest = dest.toString();
        StringBuilder res = new StringBuilder();
        int c = 0;
        for (int i = 31; i >= 0; i--) {
            boolean x = (Src.charAt(i) == '1');
            boolean y = (Dest.charAt(i) == '1');
            char z = '0';
            //模拟结果位和进位的真值表
            if (c == 0) {
                z = (x ^ y) ? '1' : '0';
                c = (x & y) ? 1 : 0;
            } else {
                z = (x ^ y ^ true) ? '1' : '0';
                c = (x | y) ? 1 : 0;
            }
            res.append(z);
        }
//
        return new DataType(res.reverse().toString());
    }

    /**
     * 返回两个二进制整数的差
     * dest - src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public static DataType sub(DataType src, DataType dest) {
        String Src = src.toString();

        char[] c = new char[32];
        for (int i = 0; i < 32; i++) {
            c[i] = (char) ('1' + '0' - Src.charAt(i));
        }
        DataType New_Src = new DataType(String.valueOf(c));
        return add(New_Src, add(dest, new DataType("00000001")));
    }

    /*
     * 和其它alu中的乘法不同，其它的返回的是datatype类型的，其实只取了低32位
     * 这里返回64位完整结果
     */
    public static String mulForFPU(DataType src, DataType dest) {
        
        //初始化寄存器
        DataType result = new DataType("00000000000000000000000000000000");
        String srcRegister = src.toString()+"0";
        //计算Y0-Y1...
        int[] y = new int[32];
        for(int i = 0; i < 32; i++){
            y[i] = srcRegister.charAt(32-i) - srcRegister.charAt(31-i);
        }
        //jisuan
        for(int i = 0; i < 32; i++){
            if(y[i] == 1){
                result = add(dest , result);
            }else if(y[i] == -1){
                result = sub(dest, result);
            }
            //右移
            //System.out.printf("y[%d]-y[%d] = %d\n",i,i-1,y[i]);
            srcRegister = result.toString().charAt(31)+srcRegister.substring(0,32);
            result = new DataType(result.toString().charAt(0)+result.toString().substring(0, 31));
            //System.out.println(result.toString()+srcRegister);
        }
        String ans = (result.toString() + srcRegister).substring(0,64);
        return ans;
    }

    public static String divForFPU(String src, String dest) {
        if( src.toString() .equals("00000000000000000000000000000000")){
            int a = 3;
            int b = 0;
            System.out.println(a/b);
            return null;
        }
        //初始化
        String quotientStr = "0000000000000000000000000000";
        String reminderStr = "0"+dest.toString();//最前面一位一不能扔掉
        String tempStr;
        for(int i = 0; i < 28; i++){
            tempStr = sub(shiftToDatatype(src),shiftToDatatype(reminderStr)).toString();
            if(tempStr.charAt(0) == '0'){
                reminderStr = tempStr.substring(32-28,32);
                quotientStr = quotientStr + "1";
            }else{
                quotientStr = quotientStr + "0";
            }
            //左移
            reminderStr = reminderStr.substring(1) + quotientStr.substring(0, 1);
            quotientStr = quotientStr.substring(1, 29);

        }
        
        return quotientStr.substring(0, 27);
    }

    public static void main(String[] args){
        //DataType src = new DataType("01000000000000000000000000000000");
        //DataType dest = new DataType("01110000000000000000000000000000");
        System.out.println(ALU.divForFPU("101000000000000000000000000", "111000000000000000000000000"));
    }
    //00000000000000000000000000000000
    public static DataType shiftToDatatype(String str){
        StringBuilder sb = new StringBuilder(str);
        int len = str.length();
        for(int i = 31; i >= len; i--){
            sb.insert(0, "0");
        }
        return new DataType(sb.toString());
    }
    public DataType subin27(DataType src, DataType dest) {
        String Src = src.toString();

        char[] c = new char[27];
        for (int i = 0; i < 27; i++) {
            c[i] = (char) ('1' + '0' - Src.charAt(i));
        }
        DataType New_Src = new DataType(String.valueOf(c));
        return add(New_Src, add(dest, new DataType("00000001")));
    }

    public DataType complementToSource(DataType srcSource){
        String srcString = srcSource.toString();
        StringBuilder sb = new StringBuilder();
        int i = 31;
        for(; i >=1; i--){
            if(srcString.charAt(i) == '0'){
                sb.insert(0, '1');
                break;
            }else{
                sb.insert(0, '0');
            }
        }
        sb.insert(0, srcString.substring(0,i));
        return new DataType(sb.toString());
    }
}
