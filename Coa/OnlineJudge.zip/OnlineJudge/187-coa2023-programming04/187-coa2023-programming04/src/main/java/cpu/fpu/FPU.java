package cpu.fpu;

import javax.swing.plaf.synth.SynthLookAndFeel;
import javax.xml.crypto.Data;

import cpu.alu.ALU;
import util.DataType;
import util.IEEE754Float;
import util.Transformer;



/**
 * floating point unit
 * 执行浮点运算的抽象单元
 * 浮点数精度：使用3位保护位进行计算
 */
public class FPU {

    public static final DataType oneDataType = new DataType("00000000000000000000000000000001");
    public static final DataType biasDataType = new DataType("00000000000000000000000001111111");
    private final String[][] addCorner = new String[][]{
        //IEEE754Float.P_ZERO:00000000000000000000000000000000
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.P_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_INF, IEEE754Float.NaN}
    };

    private final String[][] subCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.P_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_INF, IEEE754Float.NaN}
    };

    private final String[][] mulCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.P_ZERO, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_ZERO, IEEE754Float.NaN}
    };

    private final String[][] divCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
    };
    public boolean notNormalized(String exp){
        //传入指数，返回是否是规格化数
        return exp.equals("00000000");
    }
    public String extractSign(String str){
        return str.substring(0, 1);
    }
    public String extractExp(String str){
        String exp = str.substring(1, 9);
        if(notNormalized(exp))return "00000001";
        return exp;
    }
    public String extractTail(String str){
        String exp = str.substring(1, 9);
        String tail = str.substring(9, 32);
        if(notNormalized(exp)) return "0"+tail+"000";
        else return "1"+tail+"000";
    }

    public static DataType shiftToDatatype(String str){
        StringBuilder sb = new StringBuilder(str);
        int len = str.length();
        for(int i = 31; i >= len; i--){
            sb.insert(0, "0");
        }
        return new DataType(sb.toString());
    }

    public static DataType shiftToDatatypeWithSign(String str, String sign){
        StringBuilder sb = new StringBuilder(str);
        int len = str.length();
        for(int i = 31; i > len; i--){
            sb.insert(0, "0");
        }
        sb.insert(0, sign);
        return new DataType(sb.toString());
    }

    //后来我知道，这个函数直接调用Transformer类的就行了
    //这几个函数应该是我从Transformer里复制粘贴过来的
    public static DataType shiftToDatatype(String str, String sign){
        StringBuilder sb = new StringBuilder(str);
        int len = str.length();
        for(int i = 30; i >= len; i--){
            sb.insert(0, sign);
        }
        sb.insert(0, sign);
        if(sign == "1") {
            ALU alu = new ALU();
            return alu.complementToSource(new DataType(sb.toString()));
        }else{
            return new DataType(sb.toString());
        }
    }

    public String binaryToInt(String binStr) {
        char[] nums = binStr.toCharArray();
        int numInt = 0;
        for(int i = 1; i < 32; i++){
            if(nums[i] == '1'){
                numInt += 1<<(31-i);
            }
        }
        if(nums[0] == '1'){
            numInt = numInt - (1<<31);
        }
        return String.valueOf(numInt);
    }
    public static void main(String[] args){
        FPU fpu = new FPU();
        //测试bias
        int biasInt = Integer.valueOf(biasDataType.toString(),2);
        System.out.println(biasInt);
        String biasStr = Transformer.intToBinary("127");
        System.out.println(biasStr.equals(biasDataType.toString()));;

        // //测试shiftToDatatypeWithSign
        // String str = "1101";
        // String sign = "1";
        // System.out.println(shiftToDatatypeWithSign(str, sign).toString().length());

        //测试右移函数
        // String str = "1010";
        // System.out.println(rightShift(str,1));//0101
        // System.out.println(rightShift(str,2));//0011
        // System.out.println(rightShift(str,3));//0001
        // System.out.println(rightShift(str,4));//0001
        // System.out.println(rightShift(str,5));//0001
        // System.out.println(rightShift(str,6));//0001

        //测试加减法
        // String src = "10000000000000000000000000000000";
        // String dest = "10000000000000000000000000000000";
        // DataType a = fpu.sub(new DataType(src),new DataType(dest));
        // System.out.println(a.toString());
        // System.out.println(fpu.rightShift("00001000",7));

        //测试乘法
        // DataType src = new DataType("01111111000000000000000000000001");
		// DataType dest = new DataType("01111111000000000000000000000001");
        // System.out.println(src.toString());
        // System.out.println(dest.toString());
		// DataType result = fpu.mul(src, dest);
        // System.out.println(result.toString());

        //测试除法
        // DataType dest = new DataType("00111110111000000000000000000000");
		// DataType src = new DataType("00111111001000000000000000000000");
        // System.out.println("00111111001100110011001100110011");
        // System.out.println("00111110101100110011001100110011");
		// DataType result = fpu.div(src, dest);
        // System.out.println(result.toString());
        
    }
    /**
     * compute the float add of (dest + src)
     */
    public DataType add1(DataType src, DataType dest) {
        // if(src.toString().equals("00000000000000000000000000000001") && dest.toString().equals("10000000010000000000000000000000") )
        // return new DataType("10000000001111111111111111111111");

        //TODO
        String destStr = dest.toString();
        String srcStr = src.toString();

        //1.处理边界情况
        if(!srcStr.substring(1).contains("1")){
            if(!destStr.substring(1).contains("1")){
                if(destStr.charAt(0) == '0' || srcStr.charAt(0) == '0' )
                return new DataType(IEEE754Float.P_ZERO);
                else return new DataType(IEEE754Float.N_ZERO);
            }
            return dest;
        } 
        else if(!destStr.substring(1).contains("1")) return src;

        if (destStr.matches(IEEE754Float.NaN_Regular) || srcStr.matches(IEEE754Float.NaN_Regular)) {
            return new DataType(IEEE754Float.NaN);
        }
        ///1）全0，（2）一正无穷一负无穷
        String checkResult = cornerCheck(addCorner, srcStr, destStr);
        if(checkResult != null)return new DataType(checkResult);
        ///都是正无穷或都是负无穷
        //一个是0，一个是无穷怎么办？
        
        if(destStr.equals(IEEE754Float.P_INF) || srcStr.equals(IEEE754Float.P_INF)) return new DataType(IEEE754Float.P_INF);
        if(destStr.equals(IEEE754Float.N_INF) || srcStr.equals(IEEE754Float.N_INF)) return new DataType(IEEE754Float.N_INF);
        

        //2.提取符号、阶码、尾数
        String destSign = extractSign(destStr);
        String destExp = extractExp(destStr);
        String destTail = extractTail(destStr);
        String srcSign = extractSign(srcStr);
        String srcExp = extractExp(srcStr);
        String srcTail = extractTail(srcStr);
        String sign = "0";
        String exp;
        String tail;


        //3.模拟运算得到中间结果
        ////1)对阶
        int numShiftDigit = Integer.parseInt(binaryToInt(ALU.sub(shiftToDatatype(srcExp), shiftToDatatype(destExp)).toString()));
        if(numShiftDigit >= 0){
            exp = destExp;
            srcTail = rightShift(srcTail, numShiftDigit);
            if(srcTail.equals("000000000000000000000000001"))return dest;
        }else{
            exp = srcExp;
            numShiftDigit = -numShiftDigit;
            destTail = rightShift(destTail, numShiftDigit);
            if(destTail.equals("000000000000000000000000001"))return src;
        }
        ////2)尾数相加减
        //如果sign是1，那么就是负数，tail的32位首位改成1，这样再做加减运算
        //1
        if(destSign.equals(srcSign)){
            sign = destSign;
            tail = ALU.add(shiftToDatatype(srcTail), shiftToDatatype(destTail)).toString();
        }else{
            tail = ALU.sub(shiftToDatatype(srcTail), shiftToDatatype(destTail)).toString();
            sign = destSign;
            if(tail.charAt(0) == '1'){
                sign = srcSign;
                tail = ALU.sub(shiftToDatatype(destTail), shiftToDatatype(srcTail)).toString();
            }
        }
        
        if(!tail.contains("1")){
            if(destSign.equals("0") || srcSign.equals("0"))
            return new DataType(IEEE754Float.P_ZERO);
            else return new DataType(IEEE754Float.N_ZERO);
        }


        //3.规格化并舍入
        ////尾数上溢,且最多一位
        if(tail.charAt(4) != '0'){
            tail = rightShift(tail, 1);
            exp = ALU.add(shiftToDatatype(exp), oneDataType).toString().substring(32-8, 32);
            ////阶码上溢,返回inf
            if(!exp.contains("0")){
                if(sign.equals("0"))return new DataType(IEEE754Float.P_INF);
                else return new DataType(IEEE754Float.N_INF);
            }
            tail = tail.substring(5);
        }else{
            tail = tail.substring(5);
            int count = 0;
            while(tail.charAt(0) != '1' & count < 27){        
                ////尾数小于27位：将尾数左移并将阶码减少，直至尾数达到27位或阶码已经减为0。
                tail = tail.substring(1) + "0";//左移
                exp = ALU.sub(oneDataType,shiftToDatatype(exp)).toString().substring(32-8);
                if(!exp.contains("1")){
                    tail = rightShift(tail, 1);
                    break;
                    //exp = alu.add(shiftToDatatype(exp), oneDataType).toString().substring(32-8, 32);
                }
                count += 1;
            }
        }
        String result = round(sign.charAt(0), exp, tail);
        return new DataType(result);
    }

    public DataType add(DataType src, DataType dest) {
        // if(src.toString().equals("00000000000000000000000000000001") && dest.toString().equals("10000000010000000000000000000000") )
        // return new DataType("10000000001111111111111111111111");

        //TODO
        String destStr = dest.toString();
        String srcStr = src.toString();

        //1.处理边界情况
        if (destStr.matches(IEEE754Float.NaN_Regular) || srcStr.matches(IEEE754Float.NaN_Regular)) {
            return new DataType(IEEE754Float.NaN);
        }
        ///2）全0，（1）一正无穷一负无穷
        String checkResult = cornerCheck(addCorner, srcStr, destStr);
        if (checkResult != null) return new DataType(checkResult);

        if (!srcStr.substring(1).contains("1")) {
            return dest;
        } else if (!destStr.substring(1).contains("1")) {
            return src;
        }

        ///都是正无穷或都是负无穷
        //一个是0，一个是无穷怎么办？
        
        if (destStr.equals(IEEE754Float.P_INF) || srcStr.equals(IEEE754Float.P_INF))
            return new DataType(IEEE754Float.P_INF);
        if (destStr.equals(IEEE754Float.N_INF) || srcStr.equals(IEEE754Float.N_INF))
            return new DataType(IEEE754Float.N_INF);


        //2.提取符号、阶码、尾数
        String destSign = extractSign(destStr);
        String destExp = extractExp(destStr);
        String destTail = extractTail(destStr);
        String srcSign = extractSign(srcStr);
        String srcExp = extractExp(srcStr);
        String srcTail = extractTail(srcStr);
        String sign = "0";
        String exp;
        String tail;


        //3.模拟运算得到中间结果
        ////1)对阶
        //destExp - srcExp
        int numShiftDigit = Integer.parseInt(binaryToInt(ALU.sub(shiftToDatatype(srcExp), shiftToDatatype(destExp)).toString()));
        if (numShiftDigit >= 0) {
            exp = destExp;
            srcTail = rightShift(srcTail, numShiftDigit);
            if (srcTail.equals("000000000000000000000000001")) return dest;
        } else {
            exp = srcExp;
            numShiftDigit = -numShiftDigit;
            destTail = rightShift(destTail, numShiftDigit);
            if (destTail.equals("000000000000000000000000001")) return src;
        }
        ////2)尾数相加减
        //如果sign是1，那么就是负数，tail的32位首位改成1，这样再做加减运算
        //1
        if (destSign.equals(srcSign)) {
            sign = destSign;
            tail = ALU.add(shiftToDatatype(srcTail), shiftToDatatype(destTail)).toString();
        } else {
            tail = ALU.sub(shiftToDatatype(srcTail), shiftToDatatype(destTail)).toString();
            sign = destSign;
            if (tail.charAt(0) == '1') {
                sign = srcSign;
                tail = ALU.sub(shiftToDatatype(destTail), shiftToDatatype(srcTail)).toString();
            }
        }
        //机考前改的，但是不对
        // tail = ALU.add(shiftToDatatypeWithSign(srcTail,srcSign), shiftToDatatypeWithSign(destTail,destSign)).toString();
        // sign = tail.substring(0,1);
        // tail = "0" + tail.substring(1);

        if (!tail.contains("1")) {
            if (destSign.equals("0") || srcSign.equals("0"))
                return new DataType(IEEE754Float.P_ZERO);
            else return new DataType(IEEE754Float.N_ZERO);
        }


        //3.规格化并舍入
        ////尾数上溢,且最多一位
        if (tail.charAt(4) != '0') {
            tail = rightShift(tail, 1);
            exp = ALU.add(shiftToDatatype(exp), oneDataType).toString().substring(32 - 8, 32);
            ////阶码上溢,返回inf
            if (!exp.contains("0")) {
                if (sign.equals("0")) return new DataType(IEEE754Float.P_INF);
                else return new DataType(IEEE754Float.N_INF);
            }
            tail = tail.substring(5);
        } else {
            tail = tail.substring(5);
            int count = 0;
            while (tail.charAt(0) != '1' & count < 27) {
                ////尾数小于27位：将尾数左移并将阶码减少，直至尾数达到27位或阶码已经减为0。
                tail = tail.substring(1) + "0";//左移
                exp = ALU.sub(oneDataType, shiftToDatatype(exp)).toString().substring(32 - 8);
                if (!exp.contains("1")) {
                    tail = rightShift(tail, 1);
                    break;
                    //exp = alu.add(shiftToDatatype(exp), oneDataType).toString().substring(32-8, 32);
                }
                count += 1;
            }
        }

        //准备机考的时候发现，这一段注释掉依然全部AC
        //后来想想，还是不要注释的好
        //这相当于在最后规格化的时候，结果为0和INF的情况都又考虑了一遍
        if (!(exp + tail).contains("1")) {
            if (destSign.equals("0") || srcSign.equals("0"))
                return new DataType(IEEE754Float.P_ZERO);
            else return new DataType(IEEE754Float.N_ZERO);
        }

        String result = round(sign.charAt(0), exp, tail);
        return new DataType(result);
    }
    /**
     * compute the float add of (dest - src)
     */
    public DataType sub(DataType src, DataType dest) {
        String srcStr = src.toString();
        String destStr = dest.toString();
        String checkResult = cornerCheck(subCorner, srcStr, destStr);
        if(checkResult != null)return new DataType(checkResult);

        if(srcStr.charAt(0) == '0'){
            srcStr = "1"+srcStr.substring(1);
        }else{
            srcStr = "0"+srcStr.substring(1);
        }

        return add(new DataType(srcStr), dest);
        // //1.处理边界情况
        // if(!srcStr.substring(1).contains("1")){
        //     if(!destStr.substring(1).contains("1")){
        //         if(destStr.charAt(0) == '1' || srcStr.charAt(0) == '1' )
        //         return new DataType(IEEE754Float.N_ZERO);
        //         else return new DataType(IEEE754Float.P_ZERO);
        //     }
        //     return dest;
        // } 
        // else if(!destStr.substring(1).contains("1")) return src;
        // ///1）全0，（2）一正无穷一负无穷
        // checkResult = cornerCheck(addCorner, srcStr, destStr);
        // if(checkResult != null)return new DataType(checkResult);
        // //都不是数值
        // if (destStr.matches(IEEE754Float.NaN_Regular) || srcStr.matches(IEEE754Float.NaN_Regular)) {
        //     return new DataType(IEEE754Float.NaN);
        // }
        // ///都是正无穷或都是负无穷
        // //一个是0，一个是无穷怎么办？
        // if(destStr.equals(IEEE754Float.P_INF) || srcStr.equals(IEEE754Float.P_INF)) return new DataType(IEEE754Float.P_INF);
        // if(destStr.equals(IEEE754Float.N_INF) || srcStr.equals(IEEE754Float.N_INF)) return new DataType(IEEE754Float.N_INF);
        
        
    }

    /**
     * compute the float mul of (dest * src)
     */
    public DataType mul(DataType src,DataType dest){
        //TODO
        String destStr = dest.toString();
        String srcStr = src.toString();

        //1.处理边界情况
        ///1）全0，（2）一正无穷一负无穷
        String checkResult = cornerCheck(mulCorner, srcStr, destStr);
        if(checkResult != null)return new DataType(checkResult);
        ///都是正无穷或都是负无穷
        //一个是0，一个是无穷怎么办？
        if (destStr.matches(IEEE754Float.NaN_Regular) || srcStr.matches(IEEE754Float.NaN_Regular)) {
            return new DataType(IEEE754Float.NaN);
        }
        String destSign = extractSign(destStr);
        String srcSign = extractSign(srcStr);
        String sign = destSign.equals(srcSign)? "0" : "1";
        if(!srcStr.substring(1).contains("1") || !destStr.substring(1).contains("1")){
            if(sign.equals("0"))return new DataType(IEEE754Float.P_ZERO);
            else return new DataType(IEEE754Float.N_ZERO);
        }
        if(destStr.equals(IEEE754Float.P_INF) || srcStr.equals(IEEE754Float.P_INF) || destStr.equals(IEEE754Float.N_INF) || srcStr.equals(IEEE754Float.N_INF)) 
        return sign.equals("0")? new DataType(IEEE754Float.P_INF) : new DataType(IEEE754Float.N_INF);
        
        //2.提取符号、阶码、尾数
        String destExp = extractExp(destStr);
        String destTail = extractTail(destStr);
        String srcExp = extractExp(srcStr);
        String srcTail = extractTail(srcStr);
        String exp;
        String tail;

        //3.模拟运算得到中间结果
        ///阶码相加
        exp = ALU.add(shiftToDatatype(srcExp), shiftToDatatype(destExp)).toString();
        exp = ALU.sub(biasDataType, shiftToDatatype(exp)).toString();
        //todo:这里的乘法不太对，不确定结果是靠左吗
        tail = ALU.mulForFPU(shiftToDatatype(srcTail), shiftToDatatype(destTail)).toString().substring(10);
        //tial这时取低54位,exp是32位
        //"010000000000000000000000000000000000000000000000000000"
        exp = ALU.add(oneDataType, shiftToDatatype(exp)).toString();

        //4.规格化并舍入后返回
        ///1)54位尾数的隐藏位为0且阶码大于0
        while (tail.charAt(0) == '0' && exp.charAt(0) == '0') {
            exp = ALU.sub(oneDataType, shiftToDatatype(exp)).toString();
            tail = tail.substring(1) + "0";
        }
        while(tail.substring(0,27).contains("1") && exp.charAt(0) == '1') {
            tail = rightShift(tail, 1);
            exp = ALU.add(oneDataType, shiftToDatatype(exp)).toString();
        }
        //exp = exp.substring(32-8,32);
        if(exp.charAt(0) == '1'){//阶码下溢
            if(sign.equals("0"))return new DataType(IEEE754Float.P_ZERO);
            else return new DataType(IEEE754Float.N_ZERO);
        }else if(exp.substring(1,32-8).contains("1")){//阶码上溢
            if(sign.equals("0"))return new DataType(IEEE754Float.P_INF);
            else return new DataType(IEEE754Float.N_INF);
        }else if(!exp.contains("1")){
            tail = rightShift(tail, 1);
        }
        
        String result = round(sign.charAt(0), exp.substring(32-8, 32), tail);

        return new DataType(result);
    }

    /**
     * compute the float mul of (dest / src)
     */
    public DataType div(DataType src,DataType dest){
        //TODO
        String destStr = dest.toString();
        String srcStr = src.toString();
        if(!srcStr.contains("1")) throw new ArithmeticException();

        //1.处理边界情况
        ///1）全0，（2）一正无穷一负无穷
        String checkResult = cornerCheck(divCorner, srcStr, destStr);
        if(checkResult != null)return new DataType(checkResult);
        ///都是正无穷或都是负无穷
        //一个是0，一个是无穷怎么办？
        if (destStr.matches(IEEE754Float.NaN_Regular) || srcStr.matches(IEEE754Float.NaN_Regular)) {
            return new DataType(IEEE754Float.NaN);
        }
        String destSign = extractSign(destStr);
        String srcSign = extractSign(srcStr);
        String sign = destSign.equals(srcSign)? "0" : "1";

        //在复习机考的时候我发现：0和INF的特殊情况是由dest决定的，因此改成把src的判断都去掉，可见的测试样例依然全部ac
        // if(!srcStr.substring(1).contains("1") || !destStr.substring(1).contains("1")){
        //     if(sign.equals("0"))return new DataType(IEEE754Float.P_ZERO);
        //     else return new DataType(IEEE754Float.N_ZERO);
        // }
        if(!destStr.substring(1).contains("1")){
            if(sign.equals("0"))return new DataType(IEEE754Float.P_ZERO);
            else return new DataType(IEEE754Float.N_ZERO);
        }

        if(destStr.equals(IEEE754Float.P_INF) || destStr.equals(IEEE754Float.N_INF)) 
        return sign.equals("0")? new DataType(IEEE754Float.P_INF) : new DataType(IEEE754Float.N_INF);
        
        //2.提取符号、阶码、尾数
        String destExp = extractExp(destStr);
        String destTail = extractTail(destStr);
        String srcExp = extractExp(srcStr);
        String srcTail = extractTail(srcStr);
        String exp;
        String tail;

        //3.模拟运算得到中间结果
        ///阶码相加
        exp = ALU.sub(shiftToDatatype(srcExp), shiftToDatatype(destExp)).toString();
        exp = ALU.add(biasDataType, shiftToDatatype(exp)).toString();
        tail = ALU.divForFPU(srcTail, destTail);//返回前27位
        //tial这时是27位,exp是32位
        //4.规格化并舍入后返回
        ///1)尾数的隐藏位为0且阶码大于0
        while (tail.charAt(0) == '0' && exp.charAt(0) == '0') {
            exp = ALU.sub(oneDataType, shiftToDatatype(exp)).toString();
            tail = tail.substring(1) + "0";
        }
        while(tail.contains("1") && exp.charAt(0) == '1') {
            tail = rightShift(tail, 1);
            exp = ALU.add(oneDataType, shiftToDatatype(exp)).toString();
        }
        //exp = exp.substring(32-8,32);
        if(exp.charAt(0) == '1'){//阶码下溢
            if(sign.equals("0"))return new DataType(IEEE754Float.P_ZERO);
            else return new DataType(IEEE754Float.N_ZERO);
        }else if(exp.substring(1,32-8).contains("1")){//阶码上溢
            if(sign.equals("0"))return new DataType(IEEE754Float.P_INF);
            else return new DataType(IEEE754Float.N_INF);
        }else if(!exp.contains("1")){
            tail = rightShift(tail, 1);
        }
        
        String result = round(sign.charAt(0), exp.substring(32-8, 32), tail.substring(0,27));

        return new DataType(result);
    }

    /**
     * check corner cases of mul and div
     *
     * @param cornerMatrix corner cases pre-stored
     * @param oprA first operand (String)
     * @param oprB second operand (String)
     * @return the result of the corner case (String)
     */
    private String cornerCheck(String[][] cornerMatrix, String oprA, String oprB) {
        for (String[] matrix : cornerMatrix) {
            // if (oprA.equals(matrix[0]) && oprB.equals(matrix[1])) {
            //     return matrix[2];
            // }
            if(oprA.equals(matrix[0])){
                if(oprB.equals(matrix[1])){
                    return matrix[2];
                }
            }
        }
        return null;
    }

    /**
     * right shift a num without considering its sign using its string format
     *
     * @param operand to be moved
     * @param n       moving nums of bits
     * @return after moving
     */
    private static String rightShift(String operand, int n) {
        StringBuilder result = new StringBuilder(operand);  //保证位数不变
        boolean sticky = false;
        for (int i = 0; i < n; i++) {
            sticky = sticky || result.toString().endsWith("1");
            result.insert(0, "0");
            result.deleteCharAt(result.length() - 1);
        }
        if (sticky) {
            result.replace(operand.length() - 1, operand.length(), "1");
        }
        return result.substring(0, operand.length());
    }

    /**
     * 对GRS保护位进行舍入
     *
     * @param sign    符号位
     * @param exp     阶码
     * @param sig_grs 带隐藏位和保护位的尾数
     * @return 舍入后的结果
     */
    private String round(char sign, String exp, String sig_grs) {
        int grs = Integer.parseInt(sig_grs.substring(24, 27), 2);
        if ((sig_grs.substring(27).contains("1")) && (grs % 2 == 0)) {
            grs++;
        }
        String sig = sig_grs.substring(0, 24); // 隐藏位+23位
        if (grs > 4) {
            sig = oneAdder(sig);
        } else if (grs == 4 && sig.endsWith("1")) {
            sig = oneAdder(sig);
        }

        if (Integer.parseInt(sig.substring(0, sig.length() - 23), 2) > 1) {
            sig = rightShift(sig, 1);
            exp = oneAdder(exp).substring(1);
        }
        if (exp.equals("11111111")) {
            return sign == '0' ? IEEE754Float.P_INF : IEEE754Float.N_INF;
        }

        return sign + exp + sig.substring(sig.length() - 23);
    }

    /**
     * add one to the operand
     *
     * @param operand the operand
     * @return result after adding, the first position means overflow (not equal to the carry to the next)
     *         and the remains means the result
     */
    private String oneAdder(String operand) {
        int len = operand.length();
        StringBuilder temp = new StringBuilder(operand);
        temp.reverse();
        int[] num = new int[len];
        for (int i = 0; i < len; i++) num[i] = temp.charAt(i) - '0';  //先转化为反转后对应的int数组
        int bit = 0x0;
        int carry = 0x1;
        char[] res = new char[len];
        for (int i = 0; i < len; i++) {
            bit = num[i] ^ carry;
            carry = num[i] & carry;
            res[i] = (char) ('0' + bit);  //显示转化为char
        }
        String result = new StringBuffer(new String(res)).reverse().toString();
        return "" + (result.charAt(0) == operand.charAt(0) ? '0' : '1') + result;  //注意有进位不等于溢出，溢出要另外判断
    }

}
