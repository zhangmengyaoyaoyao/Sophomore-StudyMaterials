package util;


import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.print.DocFlavor.STRING;


public class Transformer {
    public static void main(String[] args){
        //System.out.println(Transformer.intToBinary("-0"));
        // Transformer.intToBinary("-2");
        // Transformer.binaryToInt("00000000000000000000000000000010");
        // Transformer.binaryToInt("11111111111111111111111111111110");
        Transformer.decimalToNBCD("10");
        //System.out.println(Transformer.NBCDToDecimal("11010000000000000000000000000000"));
        //Transformer.floatToBinary("" + Double.MAX_VALUE);
        //System.out.println(Transformer.floatToBinary("-7.25"));
        //System.out.println( Transformer.binaryToFloat("11111111100000000000000000000000"));
        // System.out.println(Math.pow(2, -127));
        //System.out.println(Float.MIN_VALUE);
    }



    public static String intToBinary(String numStr) {
        //1.负0和最小负数的特殊情况
        if(numStr == "-0"){//负0
            return "00000000000000000000000000000000";
        }
        if(numStr == "-2147483648"){//2的31次幂
            return "10000000000000000000000000000000";
        }

        int numInt = Integer.parseInt(numStr);
        //2.判断正负，用isMinus记录
        boolean isMinus = false;
        if(numInt < 0){
            isMinus = true;
            numInt = -numInt;
        }
        //3.依次模2得到了二进制串
        StringBuffer sb = new StringBuffer();
        for(int i = 0; i < 32; i++){
            sb.insert(0, numInt%2 + "");
            numInt = (numInt-numInt%2) / 2;
        }
        //System.out.println("原码表示为："+sb);
        //4.正负数有不同情况
    //正数三码统一，不用处理
        if(!isMinus){
            //System.out.println("补码表示为："+sb);
            return sb.toString();
        }
    //负数将原码转换成补码
        char[] nums = sb.toString().toCharArray();
        nums[0] = '1';
        //各位取反
        for(int i = 31; i >= 1; i--){
            if(nums[i] == '1'){
                nums[i] = '0';
            }else{
                nums[i] = '1';
            }
        }
        //末位加一
        for(int i = 31; i >= 1; i--){
            if(nums[i] == '0'){
                nums[i] = '1';
                break;
            }else{
                nums[i] = '0';
            }
        }
        String numBin = String.valueOf(nums);
        //System.out.println("补码表示为："+numBin);
        //System.out.println("10000000000000000000000000000000");
        return numBin;
    }

    public static String binaryToInt(String binStr) {
        char[] nums = binStr.toCharArray();
        int numInt = 0;
        /*
         * 第一种方法是先把负数的补码转化成原码，过程较为复杂，但是是intToBinary的重复
         */
        // if(nums[0] == '1'){
        //     for(int i = 31; i >= 1; i--){
        //         if(nums[i] == '1'){
        //             nums[i] = '0';
        //         }else{
        //             nums[i] = '1';
        //         }
        //     }
        //     for(int i = 31; i >= 1; i--){
        //         if(nums[i] == '0'){
        //             nums[i] = '1';
        //             break;
        //         }else{
        //             nums[i] = '0';
        //         }
        //     }
        // }
        /*
         * 第二种方法直接用公式
         */
        for(int i = 1; i < 32; i++){
            if(nums[i] == '1'){
                numInt += 1<<(31-i);
                // System.out.println(1<<(31-i));
                // System.out.print("num:");
                // System.out.println(numInt);
            }

        }
        if(nums[0] == '1'){
            numInt = numInt - (1<<31);
        }
        //System.out.println(numInt);
        return String.valueOf(numInt);
    }

    public static String decimalToNBCD(String decimalStr) {
        char[] NBCDchars = new char[32];
        int decimalNum = Integer.parseInt(decimalStr);
        int len = decimalStr.length();
        for(int i = 0; i < 32; i++){
            NBCDchars[i] = '0';
        }
        if(decimalNum >= 0){
            NBCDchars[0] = '1';
            NBCDchars[1] = '1';
            NBCDchars[2] = '0';
            NBCDchars[3] = '0';
        }else{
            NBCDchars[0] = '1';
            NBCDchars[1] = '1';
            NBCDchars[2] = '0';
            NBCDchars[3] = '1';
            len--;
        }
        for(int i = 0; i < len; i++){
            String str = intToBinary(decimalStr.charAt(len-1-i)+"");
            NBCDchars[31-i*4] = str.charAt(31);
            NBCDchars[31-i*4-1] = str.charAt(30);
            NBCDchars[31-i*4-2] = str.charAt(29);
            NBCDchars[31-i*4-3] = str.charAt(28);
        }
        String NBCDStr = String.valueOf(NBCDchars);
        //System.out.println(NBCDStr);
        return NBCDStr;
    }

    public static String NBCDToDecimal(String NBCDStr) {
    //0的特殊情况
        if(NBCDStr.substring(4).equals( "0000000000000000000000000000")) {
            return "0";
        }
        System.out.println(NBCDStr.substring(4));
        System.out.println("0000000000000000000000000000");
        String decimalStr = "";
        char[] NBCDchars = NBCDStr.toCharArray();
        char[] binaryInt = new char[32];
        for(int i = 0; i < 32-4; i++){
            binaryInt[i] = 0;
        }
        String d;
        for(int i = 1; i < 8; i++){
            for(int j = 0; j < 4; j++){
                binaryInt[28+j] = NBCDchars[4*i+j];
            }
            d = binaryToInt(String.valueOf(binaryInt));
            decimalStr += d;
        }
        decimalStr = decimalStr.replaceFirst("^0*", "");
        if(NBCDchars[3] == '1'){
            decimalStr = "-"+decimalStr;
        }
        //System.out.println(decimalStr);
        return decimalStr;
    }

    public static String floatToBinary(String floatStr) {
        if(floatStr == "-0") return "10000000000000000000000000000000";
        float floatFlo = Float.parseFloat(floatStr);
        //System.out.println(floatFlo);

        //判断正负
        boolean isMinus = false;
        if(floatStr.charAt(0) == '-'){
                isMinus = true;
                floatFlo = -floatFlo;
        }

        //正负无穷的溢出
        if(floatFlo >= Float.MAX_VALUE){
            return isMinus? "-Inf" : "+Inf";
        }
        
        String tailStr = "";
        String expStr = "";
        if(floatFlo < Math.pow(2, -126)){   //非规格化数
            //乘以126倍
            floatFlo *= Math.pow(2,126);
            //floatFlo *= 1<<126;不行，为什么呢，可能和1<<126是int型，pow返回值是double型有关
            System.out.println("非规格化数");
            expStr = "00000000";
            for(int i = 0; i < 23; i++){
                 floatFlo *= 2;
                if(floatFlo >= 1){
                    tailStr += "1";
                    floatFlo -= 1;
                }else{
                    tailStr += "0";
                }
            }

        }else{  //规格化数
            System.out.println("规格化数");
            //System.out.println(floatFlo);

            int expInt = 0;
            for(int i = -125; i <= 128; i++){
                if(floatFlo < Math.pow(2, i)){
                    floatFlo = floatFlo*(float)Math.pow(2, -i+1) - 1;
                    //System.out.println(floatFlo);

                    expInt = i+127-1;
                    break;
                }
            }
            for(int i = 0; i < 23; i++){
                 floatFlo *= 2;
                //System.out.println(floatFlo);

                if(floatFlo >= 1){
                    tailStr += "1";
                    floatFlo -= 1;
                }else{
                    tailStr += "0";
                }
            }
            expStr = intToBinary(String.valueOf(expInt)).substring(24);
        }
        //System.out.println(tailStr);
        String binStr = isMinus? "1":"0";
        binStr += expStr;
        binStr += tailStr;
        //System.out.println(binStr);

        return binStr;
    }

    public static String binaryToFloat(String binStr) {
        String floStr = "";
        //test
        float floFlo = 0;
        //符号位
        boolean isMinus = false;
        if(binStr.charAt(0) == '1'){
            isMinus = true;
            floStr += "-";
            System.out.printf("flotStr:%s\n",floStr);
        }
        //初始化exp和tail部分
        String expStr = binStr.substring(1,9);
        String tailStr = binStr.substring(9, 32);
        int expInt = Integer.parseInt(expStr, 2);
        int tailInt = Integer.parseInt(tailStr,2);
        System.out.println(expInt);
        
        //指数1-8位
        if(expInt == 0){
            if(tailInt == 0){
                if(isMinus)return String.valueOf(-(float)0);
                else return String.valueOf((float)0);
            }else{
                for(int i = 0; i < 23; i++){
                    floFlo += Integer.parseInt(tailStr.charAt(i)+"")*Math.pow(2,(-i-1));
                }
                floFlo = (float) (floFlo * Math.pow(2, -126));
            }
        }else if(expInt == 255){
            if(tailInt == 0){
                return isMinus ? "-Inf" : "+Inf";
            }else{
                return "NaN";
            }
        }else{  //exp不全为0，也不全为1,规格化数
            floFlo = 1;
            for(int i = 0; i < 23; i++){
                floFlo += Integer.parseInt(tailStr.charAt(i)+"")*Math.pow(2,(-i-1));
            }
            floFlo = (float) (floFlo * Math.pow(2, expInt-127));
        }
        floStr += String.valueOf(floFlo);
        System.out.println(floStr);
        return floStr;
    }

}
