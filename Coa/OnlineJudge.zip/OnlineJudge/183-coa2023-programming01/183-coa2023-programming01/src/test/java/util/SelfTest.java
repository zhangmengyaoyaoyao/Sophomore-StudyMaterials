package util;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class SelfTest {

    @Test
    public void intToBinaryTest1() {
        assertEquals("00000000000000000000000000000000", Transformer.intToBinary("-1"));
    }

    @Test
    public void binaryToIntTest1() {
        assertEquals("2", Transformer.binaryToInt("00000000000000000000000000000010"));
    }

    @Test
    public void decimalToNBCDTest1() {
        assertEquals("11000000000000000000000000010000", Transformer.decimalToNBCD("10"));
    }

    @Test
    public void NBCDToDecimalTest1() {
        assertEquals("0", Transformer.NBCDToDecimal("11000000000000000000000000000000"));
    }

    @Test
    public void floatToBinaryTest1() {
        assertEquals("00000000010000000000000000000000", Transformer.floatToBinary(String.valueOf(Math.pow(2, -127))));
    }

    @Test
    public void floatToBinaryTest2() {
        assertEquals("+Inf", Transformer.floatToBinary("" + Double.MAX_VALUE)); // 对于float来说溢出
    }

    @Test
    public void floatToBinaryTest3() {
        assertEquals("+Inf", Transformer.floatToBinary("" + Double.MAX_VALUE)); // 对于float来说溢出
    }

    @Test
    public void floatToBinaryTest4() {
        assertEquals("00000000010100000000000000000000", Transformer.floatToBinary(String.valueOf(Math.pow(2, -127)+Math.pow(2, -129))));
        assertEquals("11000000111110000000000000000000", Transformer.floatToBinary(String.valueOf(-7.75)));

    }

    @Test
    public void binaryToFloatTest1() {
        assertEquals(String.valueOf(-(float) Math.pow(2, -127)), Transformer.binaryToFloat("10000000010000000000000000000000"));
    }

    @Test
    public void binaryToFloatTest2() {
        assertEquals(String.valueOf((float)( Math.pow(2, -128)+Math.pow(2, -127)+Math.pow(2, -129))), Transformer.binaryToFloat("00000000011100000000000000000000"));
    }

    @Test
    public void binaryToFloatTest3() {
        assertEquals(String.valueOf(-(float)( Math.pow(2, -128)+Math.pow(2, -127)+Math.pow(2, -129))), Transformer.binaryToFloat("10000000011100000000000000000000"));
    }

    @Test
    public void binaryToFloatTest4() {
        assertEquals(String.valueOf(-(float)(Math.pow(2, -124)+Math.pow(2, -125))), Transformer.binaryToFloat("10000001110000000000000000000000"));
    }

    @Test
    public void binaryToFloatTest5() {
        assertEquals(String.valueOf(-7.75), Transformer.binaryToFloat("11000000111110000000000000000000"));
    }

}
