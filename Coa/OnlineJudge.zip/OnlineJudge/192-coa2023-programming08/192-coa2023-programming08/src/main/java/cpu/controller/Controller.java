package cpu.controller;

import java.nio.charset.StandardCharsets;

import cpu.alu.ALU;
import memory.Memory;
import util.DataType;
import util.Transformer;


public class Controller {
    // general purpose register通用寄存器
    char[][] GPR = new char[32][32];
    // program counter计数器
    char[] PC = new char[32];
    // instruction register指令寄存器
    char[] IR = new char[32];
    // memory address register地址寄存器
    char[] MAR = new char[32];
    // memory buffer register缓冲寄存器
    char[] MBR =  new char[32];
    char[] ICC = new char[2];

    private final String getInstructStatus = "00";
    private final String findOperandStatus = "01";
    private final String operateStatus = "10";
    private final String interruptStatus = "11";
    //TODO
    private final DataType inDataType32 = new DataType("00000000000000000000000000000100");
    Memory memory = Memory.getMemory();


    // 单例模式
    private static final Controller controller = new Controller();

    private Controller(){
        //规定第0个寄存器为zero寄存器
        GPR[0] = new char[]{'0','0','0','0','0','0','0','0',
                '0','0','0','0','0','0','0','0',
                '0','0','0','0','0','0','0','0',
                '0','0','0','0','0','0','0','0'};
        ICC = new char[]{'0','0'}; // ICC初始化为00
    }

    public static Controller getController(){
        return controller;
    }

    public void reset(){
        PC = new char[32];
        IR = new char[32];
        MAR = new char[32];
        GPR[0] = new char[]{'0','0','0','0','0','0','0','0',
                '0','0','0','0','0','0','0','0',
                '0','0','0','0','0','0','0','0',
                '0','0','0','0','0','0','0','0'};
        ICC = new char[]{'0','0'}; // ICC初始化为00
        interruptController.reset();
    }

    //中断控制器
    public InterruptController interruptController = new InterruptController();

    public ALU alu = new ALU();

    public void tick(){
        // TODO:还没实现后两条功能，也没进行下一时段要进入的状态
        //do {
            if(String.valueOf(ICC).equals(getInstructStatus)){
                getInstruct();
                //如何判断是否需要进入间址周期？ir中的操作码
                if(String.valueOf(IR).substring(0,7).equals( "1101110")){
                    ICC = findOperandStatus.toCharArray();
                }else{
                    ICC = operateStatus.toCharArray();
                }
            }else if(String.valueOf(ICC).equals(findOperandStatus)){
                findOperand();
                ICC = operateStatus.toCharArray();
            }else if(String.valueOf(ICC).equals(operateStatus)){
                operate();
                ICC = getInstructStatus.toCharArray();
            }else if(String.valueOf(ICC).equals(interruptStatus)){
                interrupt();//实际上实验里是不存在这种情况的，interrupt用指令模拟了
            }
        //} while (!ICC.toString().equals(getInstructStatus));
        
    }

    /** 执行取指操作 */
    private void getInstruct(){
        // TODO
        System.arraycopy(PC, 0, MAR, 0, 32);
        MBR = getDataWithMAR(MAR);
        // byte[] nextAddressInByte = memory.read(String.valueOf(MAR), 4);
        // MBR = new String(nextAddressInByte, StandardCharsets.UTF_8).toCharArray();
        PC = alu.add(new DataType(String.valueOf(PC)), inDataType32).toString().toCharArray();
        System.arraycopy(MBR, 0, IR, 0, 32);
    }

    /** 执行间址操作 */
    //rs2中，间址周期前是一个物理地址的物理地址，间址周期后是物理地址
    private void findOperand(){
        // TODO
        //1. 将 rs2 中的内容加载到 MAR 中
        int indexInrs2 = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(20, 25)));
        MAR = GPR[indexInrs2];
        //2. 根据 MAR 中的地址读出内存中对应数据存回 rs2 中
        GPR[indexInrs2] = getDataWithMAR(MAR);
        //根据 MAR 中的地址读出内存中对应数据存回 rs2 中,这句话中rs2是一个寄存器吗，还是指令中的rs2部分————后来我才知道是通用寄存器的编号
    }

    /** 执行周期 */
    //有 add, addi, lw, lui, jalr, ecall六种指令
    private void operate(){
        // TODO
        String opcode = String.valueOf(IR).substring(0,7);
        if(opcode.equals("1100110")){ //add
            executeAdd();
        }else if(opcode.equals("1100100")){
            executeAddi();
        }else if(opcode.equals("1100000")){
            executelw();
        }else if(opcode.equals("1110110")){
            executelui();
        }else if(opcode.equals("1110011")){
            executejalr();
        }else if(opcode.equals("1100111")){
            executeecall();
        }
    }

    /** 执行中断操作 */
    private void interrupt(){
        // TODO
        interruptController.handleInterrupt();
        //interruptController.reset();
        interruptController.signal = false;
        System.arraycopy(GPR[1], 0, IR, 0, 32);
    }

    public class InterruptController{
        // 中断信号：是否发生中断
        public boolean signal;
        public StringBuffer console = new StringBuffer();
        /** 处理中断 */
        public void handleInterrupt(){
            console.append("ecall ");
        }
        public void reset(){
            signal = false;
            console = new StringBuffer();
        }
    }

    // 以下一系列的get方法用于检查寄存器中的内容进行测试，请勿修改

    // 假定代码程序存储在主存起始位置，忽略系统程序空间
    public void loadPC(){
        PC = GPR[0];
    }

    public char[] getRA() {
        //规定第1个寄存器为返回地址寄存器
        return GPR[1];
    }

    public char[] getGPR(int i) {
        return GPR[i];
    }

    private char[] getDataWithMAR(char[] MAR){
        byte[] dataInByte = memory.read(String.valueOf(MAR), 4);//读出rs2中的地址中的内容，是一个存储器地址
        //char[] dataInChar = new String(dataInByte, StandardCharsets.UTF_8).toCharArray();// 使用 UTF-8 编码将 byte 数组转换为 char 数组
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 4; i++){
            sb.append(Transformer.intToBinary(String.valueOf(dataInByte[i])).substring(24));
        }
        return sb.toString().toCharArray();
    }

    private void executeAdd(){
        //寄存器寻址：寄存器中就是操作数
        int indexInrd = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(7, 12)));
        int indexInrs1 = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(15, 20)));
        int indexInrs2 = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(20, 25)));
        GPR[indexInrd] = alu.add(new DataType(String.valueOf(GPR[indexInrs1])), new DataType(String.valueOf(GPR[indexInrs2]))).toString().toCharArray();
    }
    private void executeAddi(){
        int indexInrd = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(7, 12)));
        int indexInrs1 = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(15, 20)));
        String immStr = "00000000000000000000".concat(String.valueOf(IR).substring(20,32));
        GPR[indexInrd] = alu.add(new DataType(String.valueOf(GPR[indexInrs1])), new DataType(immStr)).toString().toCharArray();
    }
    private void executelw(){
        int indexInrd = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(7, 12)));
        int indexInrs1 = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(15, 20)));
        String immStr = "00000000000000000000".concat(String.valueOf(IR).substring(20,32));
        MAR = alu.add(new DataType(String.valueOf(GPR[indexInrs1])), new DataType(immStr)).toString().toCharArray();
        GPR[indexInrd] = getDataWithMAR(MAR);
    }
    private void executelui(){
        String immStr = String.valueOf(IR).substring(12,32).concat("000000000000");
        int indexInrd = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(7, 12)));
        GPR[indexInrd] = immStr.toCharArray();
    }
    private void executejalr(){
        // jalr: 保存并跳转指令。在改变 PC 之前，我们要先将返回的位置保存到 ra 寄存器中，我们规定 GPR 的第 1 个寄存器是返回地址寄存器（第 0 个 GPR 寄存器保存 0）
        //pc+4先存到GPR[1](ra)中
        System.arraycopy(PC, 0, GPR[1], 0, 32);
        //pc+4存到rd对应的寄存器中
        int indexInrd = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(7, 12)));
        System.arraycopy(PC, 0, GPR[indexInrd], 0, 32);
        //指令（IR）跳转到rs1+imm处
        String immInt = "00000000000000000000".concat(String.valueOf(IR).substring(20,32));
        int indexInrs1 = Integer.parseInt(Transformer.binaryToInt(String.valueOf(IR).substring(15, 20)));
        IR = alu.add(new DataType(immInt), new DataType(String.valueOf(GPR[indexInrs1]))).toString().toCharArray();
    }
    private void executeecall(){
        //系统调用中断指令。
        //要保存返回位置，
        System.arraycopy(IR, 0, GPR[1], 0, 32);
        //同时要设置中断控制器。
        interruptController.signal = true;
        interrupt();
        ICC = getInstructStatus.toCharArray();
    }


}
